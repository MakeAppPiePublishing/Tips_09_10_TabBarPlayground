//
//  A Demo for iOS Development Tips Weekly
//  by Steven Lipton (C)2020, All rights reserved
// Check out the video series on LinkedIn learning at https://linkedin-learning.pxf.io/YxZgj
//  For code go to http://bit.ly/AppPieGithub

import UIKit
import PlaygroundSupport

class ViewControllerOne:UIViewController{
    var label = UILabel()
    
    func layoutLabel(text:String){
        label.font = UIFont.preferredFont(forTextStyle: .largeTitle)
        label.text = text
        label.adjustsFontSizeToFitWidth = true
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
        // Center  the label in the view.
        var constraints = [NSLayoutConstraint(item: label, attribute: .centerX, relatedBy: .equal, toItem: view, attribute: .centerX, multiplier: 1.0, constant: 0.0)]
        constraints += [NSLayoutConstraint(item: label, attribute: .centerY, relatedBy: .equal, toItem: view, attribute: .centerY, multiplier: 1.0, constant: 0.0)]
        view.addConstraints(constraints)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutLabel(text: "One View Controller")
    }
    
    
    override func loadView() {
        let view = UIView()
        view.backgroundColor = UIColor.systemBackground
        self.view = view
    }
}


class ViewControllerTwo:UIViewController{
    var label = UILabel()
    
    func layoutLabel(text:String){
        label.font = UIFont.preferredFont(forTextStyle: .largeTitle)
        label.text = text
        label.adjustsFontSizeToFitWidth = true
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
        // Center  the label in the view.
        var constraints = [NSLayoutConstraint(item: label, attribute: .centerX, relatedBy: .equal, toItem: view, attribute: .centerX, multiplier: 1.0, constant: 0.0)]
        constraints += [NSLayoutConstraint(item: label, attribute: .topMargin, relatedBy: .equal, toItem: view, attribute: .topMargin, multiplier: 1.0, constant: 30.0)]
        view.addConstraints(constraints)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        layoutLabel(text: "Two View Controller")
    }
    
    
    override func loadView() {
        let view = UIView()
        view.backgroundColor = UIColor.systemBackground
        self.view = view
    }
}

let vc1 = ViewControllerOne()
let vc2 = ViewControllerTwo()

vc1.title = "VC One"
vc2.title = "VC Two"

vc1.tabBarItem.image = UIImage(systemName:"1.circle")
vc2.tabBarItem.image = UIImage(systemName:"2.circle")
vc1.tabBarItem.selectedImage = UIImage(systemName:"1.circle.fill")
vc2.tabBarItem.selectedImage = UIImage(systemName:"2.circle.fill")






let tabBarVC = UITabBarController()
tabBarVC.viewControllers = [vc1,vc2]

PlaygroundPage.current.liveView = tabBarVC

